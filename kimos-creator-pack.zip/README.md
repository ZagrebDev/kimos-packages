# KIMOS — Pack para creadores de apps

Kit completo para crear apps instalables de KIMOS.

## Contenido

- CREA-TU-APP.md      → EMPIEZA AQUÍ: guía paso a paso (quickstart de 10 min).
- APP-SPEC.md         → referencia técnica del contrato AppShell.
- tools/pack.mjs      → empaquetador: node tools/pack.mjs <carpeta-de-tu-app>
                        genera el archivo .kapp listo para instalar.
- ejemplos/           → dos apps de terceros completas y comentadas:
    miorg.encuestas   → encuesta incrustable (gateway público, sin backend).
    miorg.buzon       → buzón de mensajes (además lee datos de otras apps).

## Flujo resumido

1. Copia un ejemplo y renómbralo con tu namespace (tuorg.mi-app).
2. Edita manifest.json y dist/index.js según la guía.
3. node tools/pack.mjs tuorg.mi-app   →   tuorg.mi-app-1.0.0.kapp
4. En KIMOS: Tienda → "Instalar desde archivo" (lo hace un superadmin).

Requisito: Node.js 18 o superior (solo para empaquetar; la app en sí no
necesita build salvo que uses TypeScript/JSX, en cuyo caso compila tú a un
bundle ESM plano).
