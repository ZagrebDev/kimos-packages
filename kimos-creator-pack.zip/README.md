# KIMOS — Pack para creadores 2.0

Kit completo para crear contenido instalable de KIMOS. Dos caminos, según lo
que quieras aportar:

## A. Crear una APP (.kapp) — si vas a programar

- CREA-TU-APP.md      → EMPIEZA AQUÍ si partes de cero: guía paso a paso.
- ALINEA-TU-APP.md    → EMPIEZA AQUÍ si YA tienes una app hecha y toca
                        entrarla al repositorio oficial: qué resuelve KIMOS
                        por ti y cómo dejar de resolverlo por tu cuenta.
- APP-SPEC.md         → referencia técnica del contrato AppShell.
- tools/check-app.mjs → revisor: node tools/check-app.mjs <carpeta-de-tu-app>
                        separa errores (hay que corregirlos) de avisos de
                        alineación (señales para revisar).
- tools/pack.mjs      → empaquetador: node tools/pack.mjs <carpeta-de-tu-app>
                        genera el archivo .kapp listo para instalar. Se niega a
                        reescribir un .kapp de la misma versión con otro bundle:
                        la Tienda ignoraría esa reinstalación en silencio.
- ejemplos/           → dos apps de terceros completas y comentadas:
    miorg.encuestas   → encuesta incrustable (gateway público, sin backend).
    miorg.buzon       → buzón de mensajes (además lee datos de otras apps).

Flujo: copia un ejemplo → renómbralo con tu namespace (tuorg.mi-app) → edita
manifest.json y dist/index.js → node tools/pack.mjs tuorg.mi-app → en KIMOS,
Tienda → "Instalar desde archivo" (lo hace un superadmin).

Lo que NO tienes que reinventar (CREA-TU-APP.md §7): la base de clientes
(`shell.records`), el almacenamiento de archivos (`shell.files`), las marcas de
la empresa (`shell.brands`) y los datos de otras apps (`shell.data`). Si tu app
se crea su propia lista de clientes o su propio bucket, el sistema acaba con
tres verdades y ninguna completa.

Antes de entregar: node tools/check-app.mjs <carpeta-de-tu-app>

## B. Crear CONOCIMIENTO para LiDARia (.krub) — sin programar

LiDARia es la app de captura 3D (LiDAR, ToF, profundidad por movimiento). Un
"pack de rubro" le enseña una industria nueva: con qué tolerancia se trabaja,
qué módulos importan y en qué orden, cómo es el flujo, qué KPI mejora, qué
normativa respetar y cómo se prepara una visita comercial de ese rubro.

- CREA-TU-RUBRO.md          → guía paso a paso (quickstart de 15 min).
- tools/pack-rubro.mjs      → empaquetador: node tools/pack-rubro.mjs mi-rubro.json
                              genera el archivo .krub listo para cargar.
- tools/lidaria-nucleo.mjs  → el validador (el MISMO que corre dentro de la app).
- tools/lidaria-payload.json→ el catálogo contra el que se valida.
- ejemplos/rubros/          → un pack real que añade un rubro y extiende otro.

Flujo: copia el ejemplo → cambia el id a tuorg.tu-rubro → describe tolerancia,
módulos, flujo, KPI y prospección → node tools/pack-rubro.mjs tu-rubro.json →
en KIMOS, LiDARia → Rubros → "Ampliar la base de conocimiento".

Un pack solo puede AÑADIR o EXTENDER: nunca borra lo que trae el producto, y
cada rubro queda marcado con su origen.

## Requisito

Node.js 18 o superior (solo para empaquetar). Una app no necesita build salvo
que uses TypeScript/JSX, en cuyo caso compila tú a un bundle ESM plano; un pack
de rubro no necesita nada: es un JSON.
